# Entry point for the application
