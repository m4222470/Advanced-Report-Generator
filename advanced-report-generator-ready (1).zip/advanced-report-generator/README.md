# Advanced Report Generator

![Interface](screenshot.png)

**نسخة ذكية متقدمة لتوليد التقارير مدعومة بالذكاء الاصطناعي**

## 💡 الميزات
- تحليل بيانات تلقائي
- كشف الشذوذ
- تحليل المشاعر والتلخيص
- دعم تنسيقات PDF/DOCX/XLSX
- ربط بـ Payeer للدفع

## 🚀 التثبيت
```bash
pip install -r requirements.txt
python main.py
```

## 🖼️ واجهة المستخدم
![Preview](screenshot.png)

## 🛒 شراء النسخة الكاملة
ادفع عبر Payeer للحصول على المميزات الكاملة (رابط الدفع يُولد آلياً داخل البرنامج)

